import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import { createRouter, createWebHistory } from 'vue-router'
import Home from './pages/Home.vue'
import Login from './pages/Login.vue'
import OAuthCallback from './pages/OAuthCallback.vue'

const routes = [
    { path: '/', component: Home },
    { path: '/login', component: Login },
    { path: '/oauth-callback', component: OAuthCallback }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

createApp(App).use(router).mount('#app')
console.log('Vue App Mounted')
