<script setup lang="ts">
</script>

<template>
  <div id="app-debug" style="border: 1px solid red; padding: 20px;">
    <h1>App Debug Header</h1>
    <router-view />
  </div>
</template>

<style scoped>
.container {
  max-width: 640px;
  margin: 0 auto;
  padding: 2rem;
}
</style>
