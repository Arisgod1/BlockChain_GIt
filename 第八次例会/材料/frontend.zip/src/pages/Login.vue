<script setup lang="ts">
import { ref, computed } from "vue";

const email = ref("");
const password = ref("");

const backend = "http://localhost:3000";

const onSubmit = async () => {
  const res = await fetch(`${backend}/api/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: email.value, password: password.value }),
  });
  if (res.ok) {
    const data = await res.json();
    localStorage.setItem("token", data.token);
    window.location.href = "/";
  }
};

const onRegister = async () => {
  const res = await fetch(`${backend}/api/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: email.value, password: password.value }),
  });
  if (res.ok) {
    await onSubmit();
  }
};
const emailParam = computed(() => encodeURIComponent(email.value));
</script>

<template>
  <div class="container">
    <h2>登录</h2>
    <form @submit.prevent="onSubmit">
      <input v-model="email" type="email" placeholder="邮箱" />
      <input v-model="password" type="password" placeholder="密码" />
      <button type="submit">登录</button>
      <button type="button" @click="onRegister">注册并登录</button>
    </form>
    <div class="oauth">
      <a :href="`${backend}/auth/google`">使用 Google 登录</a>
      <a :href="`${backend}/auth/dev/callback?email=${emailParam}`"
        >开发回退登录</a
      >
    </div>
  </div>
</template>

<style scoped>
.container {
  max-width: 480px;
  margin: 2rem auto;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
form {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
.oauth {
  display: flex;
  gap: 1rem;
}
</style>
