<script setup lang="ts">
import { onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
const router = useRouter()
const route = useRoute()
onMounted(() => {
  const token = route.query.token as string | undefined
  if (token) {
    localStorage.setItem('token', token)
    router.push('/')
  } else {
    router.push('/login')
  }
})
</script>

<template>
  <div class="container">
    <div>处理中...</div>
  </div>
</template>

<style scoped>
.container { padding: 2rem; }
</style>
