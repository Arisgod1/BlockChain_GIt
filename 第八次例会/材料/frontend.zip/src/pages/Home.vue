<script setup lang="ts">
import { onMounted, ref } from "vue";
import { useRouter } from "vue-router";

const router = useRouter();
const backend = "http://localhost:3000";
const me = ref<{ email: string } | null>(null);

onMounted(async () => {
  const token = localStorage.getItem("token");
  if (!token) {
    router.push("/login");
    return;
  }
  const res = await fetch(`${backend}/api/me`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (res.ok) {
    me.value = await res.json();
  } else {
    localStorage.removeItem("token");
    router.push("/login");
  }
});

const logout = () => {
  localStorage.removeItem("token");
  router.push("/login");
};
</script>

<template>
  <div class="container">
    <h2>首页</h2>
    <div v-if="me">欢迎，{{ me.email }}</div>
    <button @click="logout">退出登录</button>
  </div>
</template>

<style scoped>
.container {
  max-width: 640px;
  margin: 2rem auto;
}
</style>
